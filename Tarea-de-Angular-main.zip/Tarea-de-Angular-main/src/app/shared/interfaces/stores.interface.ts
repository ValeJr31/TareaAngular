export interface Store {
  id: number;
  name: string;
  address: string;
  city: string;
  openingHours: string;
}
